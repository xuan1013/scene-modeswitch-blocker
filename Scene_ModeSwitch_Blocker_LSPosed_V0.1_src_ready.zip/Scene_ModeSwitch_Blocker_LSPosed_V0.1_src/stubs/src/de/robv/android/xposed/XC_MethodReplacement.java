package de.robv.android.xposed;

public abstract class XC_MethodReplacement extends XC_MethodHook {
    protected XC_MethodReplacement() { super(); }
    protected XC_MethodReplacement(int priority) { super(priority); }
    protected abstract Object replaceHookedMethod(MethodHookParam param) throws Throwable;
}
