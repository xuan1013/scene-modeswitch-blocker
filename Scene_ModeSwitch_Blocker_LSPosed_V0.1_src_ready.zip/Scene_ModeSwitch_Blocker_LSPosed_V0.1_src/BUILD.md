# Build

## GitHub Actions

This repository already contains `.github/workflows/build.yml`.

1. Push the project to a GitHub repository.
2. Open **Actions → Build APK → Run workflow**.
3. Download the artifact **Scene-ModeSwitch-Blocker-V0.1**.
4. Install `Scene_ModeSwitch_Blocker_LSPosed_V0.1.apk`.
5. In LSPosed, enable the module and scope it only to `com.omarea.vtools` (Scene).
6. Disable the HookNext T0 interception before validating the dedicated module.

The workflow also produces `SHA256SUMS.txt`.

## Validation baseline

Target environment used for runtime validation before this module was created:

- Scene 9.3.6 / EP 20260815
- LSPosed 2.0.1 / API 101
- Android 16
- Hook target: `a.e50.T0(String,String,String,String,String,boolean,boolean,a.z52)`
- Expected behavior: skip original method and return `null`

After installation, verify:

- Scene accessibility works.
- Scene power statistics work.
- Scene dynamic refresh rate works.
- `core_ctl` remains `1 / 1` through app switching and screen off/on.

If Scene updates and the target signature changes, this module intentionally fails to install the hook instead of fuzzy-matching another method.
