# Scene 调度阻断器 V0.1

一个只针对当前已验证 Scene 版本的极小 LSPosed 模块。

## 目标

保留：

- Scene 无障碍
- Scene 功耗统计
- Scene 动态刷新率
- scene-daemon
- Scene EP 总开关

阻断：

- Scene Java 层 `mode-switch` 性能模式切换入口

当前精确 Hook：

```text
a.e50.T0(
  java.lang.String,
  java.lang.String,
  java.lang.String,
  java.lang.String,
  java.lang.String,
  boolean,
  boolean,
  a.z52
)
```

行为：跳过原方法并返回 `null`。

这是对 HookNext 已连续实机验证两天的规则进行固化，不增加新的调度逻辑。

## 已验证环境

- Scene 9.3.6
- Scene EP 20260815
- Android 16 / API 36
- LSPosed 2.0.1 (7639), API 101
- 设备：Redmi K90 Pro Max / myron / SM8850
- 与 `Scene 官调透传 KSU V1.1` 配合测试

## 安装后的测试顺序

1. 安装 APK。
2. 在 LSPosed 中启用本模块。
3. 作用域只勾选 `Scene / com.omarea.vtools`。
4. **先禁用 HookNext 里现有的 T0 拦截规则**，避免双重 Hook。
5. 强制停止 Scene 后重新打开，或直接重启手机。
6. Scene EP 总开关保持开启，无障碍保持开启。
7. 验证功耗统计、动态刷新率均正常。
8. 在 root 终端检查：

```sh
cat /sys/devices/system/cpu/cpu0/core_ctl/enable
cat /sys/devices/system/cpu/cpu6/core_ctl/enable
```

预期持续为：

```text
1
1
```

## 日志

模块只记录安装成功和最初 12 次被阻断的 T0 调用，便于验证，不长期刷日志。

LSPosed 日志中搜索：

```text
[SceneModeBlocker]
```

## 回滚

1. 在 LSPosed 中停用本模块。
2. 强制停止并重新打开 Scene。
3. 如果此前已经被 Scene 写成 `core_ctl=0/0`，需要重启恢复官方基线。

## 版本安全策略

V0.1 不尝试通配或猜测新版本方法。

如果 Scene 更新导致 `a.e50.T0(...)` 签名变化，模块会 Hook 失败并写日志，不会继续猜其他方法。更新 Scene 后应重新验证再升级本模块。

## 构建

本项目包含 GitHub Actions：`.github/workflows/build.yml`。

也可以本地使用 Android SDK 36 + Gradle 8.10.2：

```sh
gradle :app:assembleDebug --no-daemon
```

输出：

```text
app/build/outputs/apk/debug/app-debug.apk
```

## Dedicated LSPosed blocker

This is intentionally narrower than HookNext: it hooks only the exact Scene 9.3.6 method signature that was runtime-validated. It does not modify Scene configuration files, the Scene native daemon, refresh-rate configuration, or kernel/sysfs state.

See `BUILD.md` for build and validation steps.
