package local.scene.modeblocker;

import java.util.concurrent.atomic.AtomicInteger;

import de.robv.android.xposed.IXposedHookLoadPackage;
import de.robv.android.xposed.XC_MethodHook;
import de.robv.android.xposed.XC_MethodReplacement;
import de.robv.android.xposed.XposedBridge;
import de.robv.android.xposed.XposedHelpers;
import de.robv.android.xposed.callbacks.XC_LoadPackage;

/**
 * Scene 9.3.6 / EP 20260815 dedicated mode-switch blocker.
 *
 * Verified target method from runtime tracing:
 *   a.e50.T0(String, String, String, String, String, boolean, boolean, a.z52)
 *
 * HookNext validation showed that skipping this method and returning null keeps
 * Scene accessibility / power statistics / refresh-rate features working while
 * preventing Scene from flipping HyperOS core_ctl from 1/1 to 0/0.
 */
public final class SceneModeBlocker implements IXposedHookLoadPackage {
    private static final String TARGET_PACKAGE = "com.omarea.vtools";
    private static final String TAG = "[SceneModeBlocker]";
    private static final AtomicInteger BLOCKED_COUNT = new AtomicInteger();
    private static volatile boolean installed;

    @Override
    public void handleLoadPackage(XC_LoadPackage.LoadPackageParam lpparam) throws Throwable {
        if (!TARGET_PACKAGE.equals(lpparam.packageName)) {
            return;
        }
        if (installed) {
            return;
        }

        try {
            final Class<?> continuationClass = XposedHelpers.findClass("a.z52", lpparam.classLoader);

            XposedHelpers.findAndHookMethod(
                    "a.e50",
                    lpparam.classLoader,
                    "T0",
                    String.class,
                    String.class,
                    String.class,
                    String.class,
                    String.class,
                    boolean.class,
                    boolean.class,
                    continuationClass,
                    new XC_MethodReplacement() {
                        @Override
                        protected Object replaceHookedMethod(XC_MethodHook.MethodHookParam param) {
                            int n = BLOCKED_COUNT.incrementAndGet();

                            // Keep production logging light: only log the first few blocks.
                            if (n <= 12) {
                                String target = arg(param.args, 1);
                                String scene = arg(param.args, 2);
                                String mode = arg(param.args, 3);
                                XposedBridge.log(TAG + " blocked T0 #" + n
                                        + " target=" + target
                                        + " scene=" + scene
                                        + " mode=" + mode);
                            }

                            // This is intentionally the same behavior validated with HookNext's
                            // "intercept method execution" rule: skip T0 and return null.
                            return null;
                        }
                    }
            );

            installed = true;
            XposedBridge.log(TAG + " hook installed for " + TARGET_PACKAGE
                    + " (tested Scene 9.3.6 / EP 20260815)");
        } catch (Throwable t) {
            // Fail closed: do not hook anything else if Scene updates / obfuscation changes.
            XposedBridge.log(TAG + " hook NOT installed; target signature not found or changed");
            XposedBridge.log(t);
        }
    }

    private static String arg(Object[] args, int index) {
        if (args == null || index < 0 || index >= args.length) {
            return "<missing>";
        }
        return String.valueOf(args[index]);
    }
}
